<template>
  <div class="cls1">
      aaaaaxxx
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.cls1{
    color: rgb(216, 147, 20);
}
</style>
