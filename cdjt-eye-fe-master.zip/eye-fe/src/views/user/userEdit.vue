<template>
  <div>
    useredit112323423a
    {{a}}
  </div>
</template>

<script>
export default {
  data(){
    return {
      a:1
    }
  }
}
</script>

<style>

</style>
