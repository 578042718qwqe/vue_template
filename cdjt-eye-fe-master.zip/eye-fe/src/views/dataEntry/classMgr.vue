<template>
  <div>classMgr</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
