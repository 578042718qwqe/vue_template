
<template>
<!-- login12 -->
  <div>
    
    hello login12


  </div>
</template>

<script>
import _ from 'lodash'
import Vue from 'vue'
 
var obj = {

}
   
export default {
  name : 'login12',
  data(){
    return obj
  },
  methods : {
      
  },
  computed: {
      
  },
  watch : {
      
  },
  

}
</script>

<style lang="scss" scoped>

</style>






























