
var dbUtil = require('../utils/dbutils')

var config = {
  // dbUrl: 'mongodb://root:GE6WoZXy0Zuii6RN@47.52.229.129:27017/admin',
  dbUrl: 'mongodb://127.0.0.1:27017/eye',
  defaultDb: 'eye' ,
  logLevel: 'debug'
   
}

 

 
module.exports = config