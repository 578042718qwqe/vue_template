
var express = require('express')
var ajaxResult = require('utils/ajaxResult')
var router = express.Router()

router.post('/user/list',function(req,res,next){
    var ret = ajaxResult.getInstance()
    

})





module.exports = router












