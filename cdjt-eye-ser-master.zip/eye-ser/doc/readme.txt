
1.项目引用使用,处理"require('../../../../xxx')" 这种难受的路径引用问题
jsconfig.json 用于vscode的代码提示
app-module-path 用于require识别前置path,需要放到app.js最开始的地方










